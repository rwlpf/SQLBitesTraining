USE WindowFunctions;
GO


SELECT 
	transaction_id,
	transaction_date
FROM dbo.transaction_history_clean
